daramad = 200
tedad_farzand = 3 
arzesh_khane = 8000
daramad_ezafi = 15
shoghl = "darman"
mahal_zendegi = "shahr"

# maliat avalie
if daramad < 50 and daramad > 0:
    maliat = daramad * 0.1

elif daramad >= 50 and daramad < 100:
    maliat = daramad * 0.2

elif daramad >= 100 and daramad < 200:
    maliat = daramad * 0.4
    
else:
    maliat = daramad * 0.5

# takhfif maliat
if tedad_farzand >= 2:
    maliat = maliat - (0.05 * maliat)

if arzesh_khane > 5000 and mahal_zendegi != "shahr":
    maliat = maliat + (maliat * 0.02)
    
if daramad_ezafi > 10:
    maliat = maliat - (maliat * 0.1)
elif daramad_ezafi <= 10 and daramad_ezafi > 0:
    maliat = maliat + (maliat * 0.05)
    
if shoghl == "darman":
    maliat = maliat - (maliat * 0.05)
elif shoghl == "mali" and daramad > 150:
    maliat = maliat + (maliat * 0.05)
elif shoghl == "azad" and daramad > 50:
    maliat = maliat + (maliat * 0.03)
elif shoghl == "azad" and daramad <= 50 and daramad > 0:
    maliat = maliat - (maliat * 0.03)
    
if mahal_zendegi == "shahr" and arzesh_khane > 7000:
    maliat = maliat + (maliat * 0.03)
elif mahal_zendegi == "roosta" and tedad_farzand > 3:
    maliat = maliat - (maliat * 0.07)

print(maliat)